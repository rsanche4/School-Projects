
public class Credential_Class {
	
	// Preprogrammed Password and ID for the user
	private static String user_ID = "HTR USER";
	private static String password = "HTR PASSWORD";
	
	public static String get_ID() {
		return user_ID;
	}
	
	public static String get_passwd() {
		return password;
	}
	
}

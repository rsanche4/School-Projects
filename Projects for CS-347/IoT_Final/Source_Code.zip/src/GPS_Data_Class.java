
public class GPS_Data_Class {
	public static double railroad_dist;
	public static int railroad_func_status;
	public static double train_speed;

}
